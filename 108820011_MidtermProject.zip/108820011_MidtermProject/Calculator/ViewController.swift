//
//  ViewController.swift
//  Calculator
//
//  Created by 莊士頡 on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var operation: UILabel!
    @IBOutlet weak var result: UILabel!
    
    let operatorsChoice = ["+", "-", "*", "/", "x", "÷"]
    let numbersChoice = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "."]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func operators(_ sender: UIButton) {
        clearOperatorsHighlight()
        clearResult()
        
        sender.backgroundColor = #colorLiteral(red: 0.9947307706, green: 0.5973751545, blue: 0, alpha: 1)
        setCtoAC()
        
        if operatorsChoice.contains(String((operation.text?.suffix(1))!)){
            operation.text?.removeLast()
        }
        
        if operation.text == ""{
            operation.text = "0"
            clearOperatorsHighlight()
        } else {
            if sender.currentTitle == "x" {
                operation.text = operation.text! + "*"
            } else if sender.currentTitle == "÷" {
                operation.text = operation.text! + "/"
            } else {
                operation.text = operation.text! + sender.currentTitle!
            }
        }
    }
    
    @IBAction func numbers(_ sender: UIButton) {
        setACtoC()
        clearOperatorsHighlight()
        clearResult()
        
        if(operation.text == "0"){
            operation.text = sender.currentTitle!
        }else if (operation.text == "-0"){
            operation.text = "-" + sender.currentTitle!
        }else if ((operation.text?.suffix(1) == "0") && (operatorsChoice.contains(String((operation.text?.suffix(2))!)))){
            
        }else{
            operation.text = operation.text! + sender.currentTitle!
        }
    }
    
    @IBAction func dot(_ sender: UIButton) {
        clearResult()
        let op = operation.text!
        var hasDot = false
        
        for char in op.reversed(){
            if operatorsChoice.contains(String(char)){
                break
            }else if(char == "."){
                hasDot = true
                break
            }
        }
        if(!hasDot){
            operation.text = operation.text! + "."
        }
        
//        if (!(operation.text?.suffix(1) == ".")){
//            operation.text = operation.text! + "."
//        }
    }
    
    @IBAction func posneg(_ sender: UIButton) {
        clearResult()
        
        let opSet = CharacterSet(["+", "-", "*", "/"])
        let opSetWithoutMinus = CharacterSet(["+", "*", "/"])
        let str = operation.text!
        
        if(operation.text == ""){
            operation.text = "-0"
        }else if((operation.text?.rangeOfCharacter(from: opSet)) == nil){
            operation.text!.insert("-", at: str.startIndex)
        }else if((operation.text?.prefix(1) == "-") && ((operation.text?.rangeOfCharacter(from: opSetWithoutMinus)) == nil)){
            operation.text?.removeFirst()
        }else{
            operation.text = "-(" + operation.text! + ")"
        }
    }
    
    @IBAction func percentage(_ sender: UIButton) {
        if(result.text != ""){
            result.text!.insert(".", at: result.text!.index(result.text!.endIndex, offsetBy: -2))
        }
        if(result.text?.prefix(1) == "."){
            result.text = "0" + result.text!
        }
    }
    
    @IBAction func equal(_ sender: UIButton) {
        let equalInvalidEnd = ["+", "-", "*", "/", "."]
        
        if(!(equalInvalidEnd.contains(String((operation.text?.suffix(1))!)))){
            let _operation = operation.text!
            let expression = NSExpression(format: _operation)
            let value = expression.toFloatingPoint().expressionValue(with: nil, context: nil) as! Double
            let answer = Float(value)
            result.text = answer.trimAndStringify
            if(result.text == "inf"){
                result.text = "0"
            }
            setCtoAC()
            
            var lastNum = ""
            var numOfZeros = 0
            for char in _operation.reversed(){
                lastNum += String(char)
                if operatorsChoice.contains(String(char)){
                    break
                }
            }
            if (lastNum.reversed().filter({ $0 == "." }).count) > 0{
                for char in lastNum{
                    if char != "0"{
                        break
                    }else{
                        numOfZeros += 1
                    }
                }
            }
            operation.text?.removeLast(numOfZeros)
            if operation.text?.suffix(1) == "."{
                operation.text?.removeLast()
            }
        }
    }
    
    @IBAction func clear(_ sender: UIButton) {
        let last = self.operation.text?.suffix(1)
        
        if sender.currentTitle == "AC" {
            operation.text = ""
            result.text = ""
            clearOperatorsHighlight()
            sender.setTitle("C", for: .normal)
        }
        
        if numbersChoice.contains(String(last!)){
            clearOperatorsHighlight()
            while(numbersChoice.contains(String((self.operation.text?.suffix(1))!))){
                operation.text?.removeLast()
            }
            showOperatorsHighlight()
            sender.setTitle("AC", for: .normal)
        }
        
        if(operation.text == ""){
            setACtoC()
        }
        
    }
    
    
    
    
    func clearResult(){
        if(result.text != ""){
            result.text = ""
        }
    }
    
    func setCtoAC(){
        for case let button as UIButton in self.view.subviews {
            if button.currentTitle == "C"{
                button.setTitle("AC", for: .normal)
            }
        }
    }
    
    func setACtoC(){
        for case let button as UIButton in self.view.subviews {
            if button.currentTitle == "AC"{
                button.setTitle("C", for: .normal)
            }
        }
    }
    
    func clearOperatorsHighlight(){
        for case let button as UIButton in self.view.subviews {
            if button.backgroundColor == #colorLiteral(red: 0.9947307706, green: 0.5973751545, blue: 0, alpha: 1){
                button.backgroundColor = #colorLiteral(red: 0.9314900041, green: 0.7990477085, blue: 0.04421167076, alpha: 1)
            }
        }
    }
    
    func showOperatorsHighlight(){
        let last = self.operation.text?.suffix(1)
        switch(last){
        case "+":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "+"{
                    button.backgroundColor = #colorLiteral(red: 0.9947307706, green: 0.5973751545, blue: 0, alpha: 1)
                }
            }
        case "-":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "-"{
                    button.backgroundColor = #colorLiteral(red: 0.9947307706, green: 0.5973751545, blue: 0, alpha: 1)
                }
            }
        case "x":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "x"{
                    button.backgroundColor = #colorLiteral(red: 0.9947307706, green: 0.5973751545, blue: 0, alpha: 1)
                }
            }
        case "÷":
            for case let button as UIButton in self.view.subviews {
                if button.currentTitle == "÷"{
                    button.backgroundColor = #colorLiteral(red: 0.9947307706, green: 0.5973751545, blue: 0, alpha: 1)
                }
            }
        default:
            for case let button as UIButton in self.view.subviews {
                if operatorsChoice.contains(button.currentTitle!){
                    button.backgroundColor = #colorLiteral(red: 0.9314900041, green: 0.7990477085, blue: 0.04421167076, alpha: 1)
                }
            }
        }

    }
}

